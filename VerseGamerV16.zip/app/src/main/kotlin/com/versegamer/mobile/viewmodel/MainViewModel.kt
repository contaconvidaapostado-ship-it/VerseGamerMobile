package com.versegamer.mobile.viewmodel

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.versegamer.mobile.engine.ShellExecutor
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val _status = MutableStateFlow("Sistema Pronto")
    val status = _status.asStateFlow()

    private val _ramUsage = MutableStateFlow("0 MB")
    val ramUsage = _ramUsage.asStateFlow()

    private val _batteryTemp = MutableStateFlow("0°C")
    val batteryTemp = _batteryTemp.asStateFlow()

    private val _shizukuActive = MutableStateFlow(false)
    val shizukuActive = _shizukuActive.asStateFlow()

    fun startMonitoring(context: Context) = viewModelScope.launch {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

        while (true) {
            // Monitor RAM
            activityManager.getMemoryInfo(memoryInfo)
            val usedRam = (memoryInfo.totalMem - memoryInfo.availMem) / 1024 / 1024
            _ramUsage.value = "${usedRam}MB / ${memoryInfo.totalMem / 1024 / 1024}MB"

            // Monitor Bateria
            val temp = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            _batteryTemp.value = "${temp}%" // Simplificado para porcentagem

            // Check Shizuku
            _shizukuActive.value = ShellExecutor.isAvailable()
            
            delay(2000) // Atualiza a cada 2 segundos
        }
    }

    fun runBoost(label: String, cmd: String) = viewModelScope.launch {
        _status.value = "Aplicando $label..."
        val res = ShellExecutor.execute(cmd)
        _status.value = "[$label] $res"
    }

    // Comandos Elite
    fun touchBoost() = runBoost("Touch", "settings put secure long_press_timeout 180; setprop debug.touch_low_latency 1")
    fun fpsBoost() = runBoost("FPS", "settings put system peak_refresh_rate 120.0; setprop debug.gr.num_framebuffers 3")
    fun netBoost() = runBoost("Net", "settings put global wifi_scan_throttle_enabled 0")
    fun godMode() = runBoost("GOD MODE", "cmd power set-fixed-performance-mode-enabled true; am kill-all")
    fun reset() = runBoost("Reset", "wm density reset; cmd power set-fixed-performance-mode-enabled false")
}