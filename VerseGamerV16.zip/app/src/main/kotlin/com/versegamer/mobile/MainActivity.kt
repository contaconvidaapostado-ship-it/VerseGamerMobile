package com.versegamer.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.versegamer.mobile.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val vm = MainViewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val context = LocalContext.current
            LaunchedEffect(Unit) { vm.startMonitoring(context) }
            GamerDashboard(vm)
        }
    }
}

@Composable
fun GamerDashboard(vm: MainViewModel) {
    val status by vm.status.collectAsState()
    val ram by vm.ramUsage.collectAsState()
    val batt by vm.batteryTemp.collectAsState()
    val shizuku by vm.shizukuActive.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFF050505)).padding(16.dp).verticalScroll(rememberScrollState())
    ) {
        // Header
        Text("VERSEGAMER", fontSize = 32.sp, fontWeight = FontWeight.Black, color = Color(0xFF00D9FF))
        Text("MOBILE OVERDRIVE ELITE", color = Color(0xFFFF0000), fontSize = 12.sp)

        Spacer(Modifier.height(20.dp))

        // Monitor de Hardware Row
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            StatusCard("RAM", ram, Color(0xFF39FF14), Modifier.weight(1f))
            StatusCard("BATT", batt, Color(0xFFFFCC00), Modifier.weight(1f))
            StatusCard("SHIZUKU", if(shizuku) "ONLINE" else "OFFLINE", if(shizuku) Color(0xFF00D9FF) else Color.Red, Modifier.weight(1f))
        }

        Spacer(Modifier.height(20.dp))

        // Console Log
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0A0A)),
            border = BorderStroke(1.dp, Color(0xFF1A1A1A))
        ) {
            Text(status, Modifier.padding(16.dp), color = Color.LightGray, fontSize = 13.sp)
        }

        Spacer(Modifier.height(25.dp))

        // Grid de Ações
        Text("CONTROLES DE PERFORMANCE", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))
        
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
            ActionButton("TOUCH BOOST", Color(0xFF00D9FF), Modifier.weight(1f)) { vm.touchBoost() }
            ActionButton("FPS BOOST", Color(0xFFFF0000), Modifier.weight(1f)) { vm.fpsBoost() }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
            ActionButton("NET BOOST", Color(0xFF39FF14), Modifier.weight(1f)) { vm.netBoost() }
            ActionButton("SYSTEM RESET", Color.White, Modifier.weight(1f)) { vm.reset() }
        }

        Spacer(Modifier.height(25.dp))

        // Botão MODO DEUS
        Button(
            onClick = { vm.godMode() },
            modifier = Modifier.fillMaxWidth().height(65.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = PaddingValues()
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFFFF0000), Color(0xFFFFCC00)))),
                contentAlignment = Alignment.Center
            ) {
                Text("ATIVAR MODO DEUS (MAX PERFORMANCE)", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun StatusCard(label: String, value: String, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111111)),
        border = BorderStroke(0.5.dp, color.copy(alpha = 0.5f))
    ) {
        Column(Modifier.padding(12.dp), Alignment.CenterHorizontally) {
            Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ActionButton(text: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(60.dp),
        border = BorderStroke(1.dp, color),
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color)
    ) {
        Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}