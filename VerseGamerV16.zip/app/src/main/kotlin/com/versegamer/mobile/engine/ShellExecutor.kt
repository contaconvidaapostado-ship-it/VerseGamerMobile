package com.versegamer.mobile.engine

import dev.rikka.shizuku.Shizuku
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

object ShellExecutor {
    // Verifica se o Shizuku está ativo e com permissão
    fun isAvailable(): Boolean {
        return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    suspend fun execute(command: String): String = withContext(Dispatchers.IO) {
        if (!Shizuku.pingBinder()) return@withContext "Shizuku Offline"
        
        return@withContext try {
            // Executa o comando shell privilegiado
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()
            output.ifBlank { "Comando enviado!" }
        } catch (e: Exception) {
            "Erro: ${e.message}"
        }
    }
}